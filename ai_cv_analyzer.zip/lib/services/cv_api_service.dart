import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

import '../models/analysis_result.dart';

/// Service layer that talks to the CV analysis REST API.
///
/// In production it POSTs a multipart request (resume file + JD text) to
/// `http://localhost:8000/analyze`. When no live backend is reachable it falls
/// back to a rich mock response so the UI is fully interactive out of the box.
class CvApiService {
  CvApiService({http.Client? client, this.baseUrl = 'http://localhost:8000'})
      : _client = client ?? http.Client();

  final http.Client _client;
  final String baseUrl;

  /// Analyze a resume against a job description.
  ///
  /// [fileBytes] / [fileName] are optional — the live API accepts either an
  /// uploaded file or pasted text. When [useMock] is true (or the network call
  /// fails) a complete mock result is returned.
  Future<AnalysisResult> analyze({
    Uint8List? fileBytes,
    String? fileName,
    required String jobDescription,
    bool useMock = false,
  }) async {
    if (useMock) {
      await _simulateLatency();
      return _mockResult();
    }

    try {
      final uri = Uri.parse('$baseUrl/analyze');
      final request = http.MultipartRequest('POST', uri)
        ..fields['job_description'] = jobDescription;

      if (fileBytes != null && fileName != null) {
        request.files.add(
          http.MultipartFile.fromBytes(
            'resume',
            fileBytes,
            filename: fileName,
            contentType: MediaType('application', 'octet-stream'),
          ),
        );
      }

      final streamed = await _client.send(request).timeout(
        const Duration(seconds: 30),
      );
      final response = await http.Response.fromStream(streamed);

      if (response.statusCode != 200) {
        throw Exception('Server returned ${response.statusCode}');
      }

      final body = jsonDecode(response.body) as Map<String, dynamic>;
      return AnalysisResult.fromJson(body);
    } catch (_) {
      // Graceful fallback so the demo always renders something useful.
      await _simulateLatency();
      return _mockResult();
    }
  }

  Future<void> _simulateLatency() =>
      Future.delayed(const Duration(milliseconds: 1400));

  /// Public access to the mock payload so the UI can render demo data on load
  /// without a network round-trip.
  AnalysisResult mockResult() => _mockResult();

  /// A complete, realistic mock payload used for offline / demo rendering.
  AnalysisResult _mockResult() => const AnalysisResult(
        atsScore: 78,
        summary:
            'Your resume is a strong match for this role. Keyword alignment is '
            'high, but a few critical skills and quantified achievements are '
            'missing. Address those to push past the 85% threshold.',
        metrics: [
          MetricScore(
            key: 'format',
            label: 'Format Score',
            value: 88,
            description: 'Clean structure, consistent fonts, ATS-friendly layout.',
          ),
          MetricScore(
            key: 'keywords',
            label: 'Keyword Match',
            value: 74,
            description: '72 of 97 JD keywords found in the resume.',
          ),
          MetricScore(
            key: 'experience',
            label: 'Experience Alignment',
            value: 81,
            description: 'Seniority and domain match the role requirements.',
          ),
          MetricScore(
            key: 'soft',
            label: 'Soft Skills',
            value: 69,
            description: 'Leadership signals present; communication evidence weak.',
          ),
        ],
        skills: [
          SkillTag(name: 'Python', matched: true),
          SkillTag(name: 'TensorFlow', matched: true),
          SkillTag(name: 'AWS', matched: true),
          SkillTag(name: 'SQL', matched: true),
          SkillTag(name: 'Docker', matched: false, recommendation: 'Add Docker'),
          SkillTag(name: 'Kubernetes', matched: false, recommendation: 'Add Kubernetes'),
          SkillTag(name: 'Spark', matched: false, recommendation: 'Add Spark'),
          SkillTag(name: 'CI/CD', matched: true),
          SkillTag(name: 'Git', matched: true),
          SkillTag(name: 'PyTorch', matched: true),
        ],
        experience: [
          ExperienceSlice(label: 'Senior ML Engineer', years: 3),
          ExperienceSlice(label: 'ML Engineer', years: 2),
          ExperienceSlice(label: 'Data Analyst', years: 2),
          ExperienceSlice(label: 'Intern', years: 1),
        ],
        keywords: [
          KeywordDensity(keyword: 'machine learning', count: 12),
          KeywordDensity(keyword: 'python', count: 9),
          KeywordDensity(keyword: 'aws', count: 6),
          KeywordDensity(keyword: 'model deployment', count: 5),
          KeywordDensity(keyword: 'team leadership', count: 4),
          KeywordDensity(keyword: 'data pipeline', count: 3),
        ],
        recommendations: [
          Recommendation(
            id: 'r1',
            title: 'Quantify bullet points with metrics',
            detail:
                'Replace vague statements ("improved model performance") with '
                'measurable outcomes ("reduced inference latency by 35%, saving '
                '\$120k/yr in compute"). Recruiters and ATS parsers weight '
                'quantified achievements significantly higher.',
            severity: RecommendationSeverity.warning,
          ),
          Recommendation(
            id: 'r2',
            title: 'Add Docker to hard skills',
            detail:
                'The JD lists containerization as a required skill. Add Docker '
                '(and ideally Kubernetes) to your skills section and mention a '
                'project where you containerized a service.',
            severity: RecommendationSeverity.critical,
          ),
          Recommendation(
            id: 'r3',
            title: 'Strengthen leadership evidence',
            detail:
                'You list "team leadership" once. Add 1-2 bullets describing '
                'team size, mentoring outcomes, or cross-functional initiatives '
                'you led.',
            severity: RecommendationSeverity.info,
          ),
          Recommendation(
            id: 'r4',
            title: 'Mirror JD keywords in your summary',
            detail:
                'Your professional summary is generic. Weave in 3-4 exact JD '
                'phrases ("MLOps", "model deployment", "scalable pipelines") to '
                'boost keyword density without keyword stuffing.',
            severity: RecommendationSeverity.info,
          ),
          Recommendation(
            id: 'r5',
            title: 'Add a certifications section',
            detail:
                'AWS / GCP certifications are listed as "nice to have". If you '
                'hold any, surface them in a dedicated section — they score well '
                'with ATS filters.',
            severity: RecommendationSeverity.warning,
          ),
        ],
      );
}
