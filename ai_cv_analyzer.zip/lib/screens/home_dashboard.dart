import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../models/analysis_result.dart';
import '../services/cv_api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/animated_score_card.dart';
import '../widgets/glass_container.dart';
import '../widgets/upload_zone.dart';

/// Responsive home screen: glassmorphic header + a two-pane layout on desktop
/// (upload left, dashboard right) collapsing to a single scrollable column on
/// mobile. State is held locally with [StatefulWidget].
class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> {
  final CvApiService _service = CvApiService();

  Uint8List? _fileBytes;
  String? _fileName;
  int? _fileSize;
  UploadStatus _uploadStatus = UploadStatus.idle;

  final TextEditingController _jdController = TextEditingController();

  bool _analyzing = false;
  AnalysisResult? _result;
  String? _error;
  bool _useMock = true;

  @override
  void initState() {
    super.initState();
    // Render the mock dashboard immediately so the app is interactive on load.
    _loadMock();
  }

  @override
  void dispose() {
    _jdController.dispose();
    super.dispose();
  }

  Future<void> _loadMock() async {
    final r = _service.mockResult();
    if (mounted) setState(() => _result = r);
  }

  Future<void> _onAnalyze() async {
    if (_jdController.text.trim().isEmpty && _fileBytes == null) {
      setState(() => _error = 'Add a resume or paste a job description first.');
      return;
    }
    setState(() {
      _analyzing = true;
      _error = null;
      if (_fileBytes != null) _uploadStatus = UploadStatus.uploading;
    });

    try {
      final result = await _service.analyze(
        fileBytes: _fileBytes,
        fileName: _fileName,
        jobDescription: _jdController.text,
        useMock: _useMock,
      );
      setState(() {
        _result = result;
        _analyzing = false;
        if (_fileBytes != null) _uploadStatus = UploadStatus.done;
      });
    } catch (e) {
      setState(() {
        _error = 'Analysis failed: $e';
        _analyzing = false;
        _uploadStatus = UploadStatus.error;
      });
    }
  }

  void _onFileSelected({required Uint8List bytes, required String name}) {
    setState(() {
      _fileBytes = bytes;
      _fileName = name;
      _fileSize = bytes.lengthInBytes;
      _uploadStatus = UploadStatus.selected;
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isDesktop = width >= 1024;
    final isTablet = width >= 640;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.bgDeep, AppColors.bgMid],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _AppHeader(isDesktop: isDesktop),
              Expanded(
                child: isDesktop
                    ? _DesktopLayout(
                        uploadPanel: _buildUploadPanel(),
                        dashboard: _buildDashboard(isDesktop: true),
                      )
                    : SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _buildUploadPanel(),
                            const SizedBox(height: 20),
                            _buildDashboard(isDesktop: false),
                          ],
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Header
  // ---------------------------------------------------------------------------
  Widget _AppHeader({required bool isDesktop}) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: GlassContainer(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          child: Row(
            children: [
              _Logo(),
              const SizedBox(width: 16),
              if (isDesktop) ..._navLinks(),
              const Spacer(),
              _ThemeToggle(),
              const SizedBox(width: 10),
              _Avatar(),
            ],
          ),
        ),
      );

  List<Widget> _navLinks() => [
        _NavLink(label: 'Dashboard', active: true),
        _NavLink(label: 'ATS Scanner'),
        _NavLink(label: 'Skill Gap'),
        _NavLink(label: 'Settings'),
      ];

  // ---------------------------------------------------------------------------
  // Upload panel (left pane on desktop)
  // ---------------------------------------------------------------------------
  Widget _buildUploadPanel() {
    return GlassContainer(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Upload & Analyze',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 4),
          Text(
            'Drop your resume and paste the job description to get an instant '
            'ATS match score with AI recommendations.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 20),
          UploadZone(
            onFileSelected: (f) => _onFileSelected(bytes: f.bytes, name: f.name),
            selectedFileName: _fileName,
            selectedFileSize: _fileSize,
            status: _uploadStatus,
          ),
          const SizedBox(height: 20),
          Text('Job Description', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          TextField(
            controller: _jdController,
            maxLines: 6,
            minLines: 4,
            style: const TextStyle(color: AppColors.textPrimary, height: 1.5),
            decoration: const InputDecoration(
              hintText:
                  'Paste the target job description here…\n\n'
                  'e.g. Senior ML Engineer — Python, TensorFlow, AWS, Docker…',
              hintStyle: TextStyle(color: AppColors.textMuted, height: 1.5),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              FilterChip(
                label: const Text('Demo data', style: TextStyle(fontSize: 12)),
                selected: _useMock,
                onSelected: (v) => setState(() => _useMock = v),
                selectedColor: AppColors.accent.withValues(alpha: 0.25),
                checkmarkColor: AppColors.accent,
                side: const BorderSide(color: AppColors.border),
              ),
              const SizedBox(width: 8),
              Text(
                _useMock ? 'Using built-in mock response' : 'Calling live API',
                style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _AnalyzeButton(onTap: _onAnalyze, loading: _analyzing),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(
              _error!,
              style: const TextStyle(color: AppColors.error, fontSize: 13),
            ).animate().shake(duration: 500.ms),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Dashboard (right pane on desktop)
  // ---------------------------------------------------------------------------
  Widget _buildDashboard({required bool isDesktop}) {
    final r = _result;
    if (_analyzing && r == null) {
      return const Center(child: _LoadingIndicator());
    }
    if (r == null) {
      return const Center(
        child: Text('No analysis yet.',
            style: TextStyle(color: AppColors.textSecondary)),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Hero score
        GlassContainer.neon(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              AnimatedScoreCard(score: r.atsScore),
              const SizedBox(height: 16),
              Text(
                r.summary,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ).animate().fadeIn(duration: 500.ms),
            ],
          ),
        ).animate().fadeIn(duration: 500.ms).slideY(begin: 0.05),
        const SizedBox(height: 16),
        // Metric cards
        _MetricGrid(metrics: r.metrics, isDesktop: isDesktop),
        const SizedBox(height: 16),
        // Skills
        _SkillBreakdown(skills: r.skills),
        const SizedBox(height: 16),
        // Charts
        _ChartsRow(experience: r.experience, keywords: r.keywords),
        const SizedBox(height: 16),
        // Recommendations
        _RecommendationsFeed(recommendations: r.recommendations),
        const SizedBox(height: 24),
      ],
    );
  }
}

// =============================================================================
// Sub-widgets (kept in-file for cohesion — all part of the dashboard screen)
// =============================================================================

class _DesktopLayout extends StatelessWidget {
  const _DesktopLayout({required this.uploadPanel, required this.dashboard});

  final Widget uploadPanel;
  final Widget dashboard;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(flex: 2, child: SingleChildScrollView(child: uploadPanel)),
          const SizedBox(width: 16),
          Expanded(flex: 3, child: dashboard),
        ],
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: AppTheme.accentGradient,
            boxShadow: [
              BoxShadow(color: AppColors.accentGlow, blurRadius: 14),
            ],
          ),
          child: const Icon(Icons.auto_awesome, color: Colors.white, size: 22),
        ),
        const SizedBox(width: 10),
        ShaderMask(
          shaderCallback: (bounds) =>
              AppTheme.accentGradient.createShader(bounds),
          child: const Text(
            'CV Analyzer AI',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ],
    )
        .animate(onPlay: (c) => c.repeat())
        .shimmer(duration: 3000.ms, color: AppColors.accent.withValues(alpha: 0.3));
  }
}

class _NavLink extends StatelessWidget {
  const _NavLink({required this.label, this.active = false});

  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Text(
        label,
        style: TextStyle(
          color: active ? AppColors.accent : AppColors.textSecondary,
          fontWeight: active ? FontWeight.w600 : FontWeight.w500,
          fontSize: 14,
        ),
      ).animate(target: active ? 1 : 0).fade(duration: 300.ms),
    );
  }
}

class _ThemeToggle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: const EdgeInsets.all(8),
      child: const Icon(Icons.dark_mode_rounded,
          color: AppColors.accent, size: 18),
    );
  }
}

class _Avatar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 18,
      backgroundColor: AppColors.accent.withValues(alpha: 0.2),
      child: const Icon(Icons.person, color: AppColors.accent, size: 20),
    );
  }
}

class _AnalyzeButton extends StatefulWidget {
  const _AnalyzeButton({required this.onTap, required this.loading});

  final VoidCallback onTap;
  final bool loading;

  @override
  State<_AnalyzeButton> createState() => _AnalyzeButtonState();
}

class _AnalyzeButtonState extends State<_AnalyzeButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.loading ? null : widget.onTap,
        child: AnimatedContainer(
          duration: 250.ms,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: AppTheme.accentGradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: AppColors.accentGlow,
                blurRadius: _hover ? 30 : 16,
                spreadRadius: _hover ? 2 : 0,
              ),
            ],
          ),
          child: Center(
            child: widget.loading
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation(Colors.white),
                    ),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.bolt_rounded, color: Colors.white, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        'Analyze Resume',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
          ),
        )
            .animate(target: _hover ? 1 : 0)
            .scale(begin: const Offset(1, 1), end: const Offset(1.03, 1.03)),
      ),
    );
  }
}

class _LoadingIndicator extends StatelessWidget {
  const _LoadingIndicator();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          width: 48,
          height: 48,
          child: CircularProgressIndicator(
            strokeWidth: 3,
            valueColor: AlwaysStoppedAnimation(AppColors.accent),
          ),
        )
            .animate(onPlay: (c) => c.repeat())
            .shimmer(duration: 1200.ms, color: AppColors.accent),
        const SizedBox(height: 16),
        const Text('Analyzing your resume…',
            style: TextStyle(color: AppColors.textSecondary)),
      ],
    );
  }
}

class _MetricGrid extends StatelessWidget {
  const _MetricGrid({required this.metrics, required this.isDesktop});

  final List<MetricScore> metrics;
  final bool isDesktop;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final crossCount = c.maxWidth >= 600 ? 2 : 1;
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossCount,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 2.4,
        ),
        itemCount: metrics.length,
        itemBuilder: (context, i) {
          final m = metrics[i];
          return GlassContainer(
            padding: const EdgeInsets.all(14),
            child: _MetricCard(metric: m),
          )
              .animate()
              .fadeIn(delay: (80 * i).ms, duration: 400.ms)
              .slideY(begin: 0.08);
        },
      );
    });
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.metric});

  final MetricScore metric;

  @override
  Widget build(BuildContext context) {
    final color = scoreColor(metric.value);
    return Row(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 46,
              height: 46,
              child: CircularProgressIndicator(
                value: metric.value / 100,
                strokeWidth: 5,
                color: color,
                backgroundColor: AppColors.bgElevated,
              ),
            ),
            Text(
              '${metric.value.round()}',
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ],
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(metric.label,
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14)),
              const SizedBox(height: 2),
              Text(metric.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 12, height: 1.3)),
            ],
          ),
        ),
      ],
    );
  }
}

class _SkillBreakdown extends StatelessWidget {
  const _SkillBreakdown({required this.skills});

  final List<SkillTag> skills;

  @override
  Widget build(BuildContext context) {
    final matched = skills.where((s) => s.matched).toList();
    final missing = skills.where((s) => !s.matched).toList();
    return GlassContainer(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Skill Match Breakdown',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 14),
          const Text('Matched Skills',
              style: TextStyle(
                  color: AppColors.success,
                  fontWeight: FontWeight.w600,
                  fontSize: 13)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: matched
                .map((s) => _SkillChip(
                      label: s.name,
                      color: AppColors.success,
                      matched: true,
                    ).animate().fadeIn(duration: 300.ms).scale(
                        begin: const Offset(0.8, 0.8)))
                .toList(),
          ),
          const SizedBox(height: 18),
          const Text('Missing Critical Skills',
              style: TextStyle(
                  color: AppColors.danger,
                  fontWeight: FontWeight.w600,
                  fontSize: 13)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: missing
                .map((s) => _SkillChip(
                      label: s.name,
                      color: AppColors.danger,
                      matched: false,
                      badge: s.recommendation,
                    ).animate().fadeIn(duration: 300.ms).scale(
                        begin: const Offset(0.8, 0.8)))
                .toList(),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 500.ms);
  }
}

class _SkillChip extends StatelessWidget {
  const _SkillChip({
    required this.label,
    required this.color,
    required this.matched,
    this.badge,
  });

  final String label;
  final Color color;
  final bool matched;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(matched ? Icons.check_circle : Icons.error_outline,
              color: color, size: 15),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  color: color, fontWeight: FontWeight.w600, fontSize: 13)),
          if (badge != null) ...[
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.25),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(badge!,
                  style: TextStyle(color: color, fontSize: 10)),
            ),
          ],
        ],
      ),
    );
  }
}

class _ChartsRow extends StatelessWidget {
  const _ChartsRow({required this.experience, required this.keywords});

  final List<ExperienceSlice> experience;
  final List<KeywordDensity> keywords;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final side = c.maxWidth >= 700;
      return Flex(
        direction: side ? Axis.horizontal : Axis.vertical,
        children: [
          Expanded(
            flex: 1,
            child: GlassContainer(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Experience Breakdown',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 180,
                    child: _ExperienceBarChart(experience: experience),
                  ),
                ],
              ),
            ),
          ),
          if (side) const SizedBox(width: 12) else const SizedBox(height: 12),
          Expanded(
            flex: 1,
            child: GlassContainer(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Keyword Density',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 180,
                    child: _KeywordPieChart(keywords: keywords),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    });
  }
}

class _ExperienceBarChart extends StatelessWidget {
  const _ExperienceBarChart({required this.experience});

  final List<ExperienceSlice> experience;

  @override
  Widget build(BuildContext context) {
    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        barTouchData: BarTouchData(enabled: true),
        titlesData: FlTitlesData(
          leftTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (v, _) {
                final i = v.toInt();
                if (i < 0 || i >= experience.length) return const Text('');
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(experience[i].label.split(' ').first,
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 10)),
                );
              },
            ),
          ),
        ),
        borderData: FlBorderData(show: false),
        gridData: const FlGridData(show: false),
        barGroups: List.generate(experience.length, (i) {
          final e = experience[i];
          return BarChartGroupData(
            x: i,
            barRods: [
              BarChartRodData(
                toY: e.years,
                width: 18,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                gradient: AppTheme.accentGradient,
              ),
            ],
          );
        }),
      ),
    );
  }
}

class _KeywordPieChart extends StatelessWidget {
  const _KeywordPieChart({required this.keywords});

  final List<KeywordDensity> keywords;

  static const _colors = [
    AppColors.accent,
    AppColors.accentDim,
    AppColors.success,
    AppColors.warning,
    AppColors.danger,
    Color(0xFF818CF8),
  ];

  @override
  Widget build(BuildContext context) {
    final total =
        keywords.fold<int>(0, (a, k) => a + k.count).toDouble();
    return Row(
      children: [
        Expanded(
          child: PieChart(
            PieChartData(
              sections: List.generate(keywords.length, (i) {
                final k = keywords[i];
                return PieChartSectionData(
                  value: k.count.toDouble(),
                  color: _colors[i % _colors.length],
                  radius: 50,
                  title: '${((k.count / total) * 100).round()}%',
                  titleStyle: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                );
              }),
              sectionsSpace: 2,
              centerSpaceRadius: 28,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(keywords.length, (i) {
              final k = keywords[i];
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: _colors[i % _colors.length],
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(k.keyword,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 12)),
                    ),
                    Text('(${k.count})',
                        style: const TextStyle(
                            color: AppColors.textMuted, fontSize: 12)),
                  ],
                ),
              );
            }),
          ),
        ),
      ],
    );
  }
}

class _RecommendationsFeed extends StatefulWidget {
  const _RecommendationsFeed({required this.recommendations});

  final List<Recommendation> recommendations;

  @override
  State<_RecommendationsFeed> createState() => _RecommendationsFeedState();
}

class _RecommendationsFeedState extends State<_RecommendationsFeed> {
  String? _expandedId;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('AI Recommendations',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 14),
          ...widget.recommendations.map((rec) {
            final expanded = _expandedId == rec.id;
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GestureDetector(
                onTap: () => setState(() =>
                    _expandedId = expanded ? null : rec.id),
                child: AnimatedContainer(
                  duration: 250.ms,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: rec.severity.color.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: rec.severity.color.withValues(alpha: 0.4)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(rec.severity.icon,
                              color: rec.severity.color, size: 20),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(rec.title,
                                style: const TextStyle(
                                    color: AppColors.textPrimary,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14)),
                          ),
                          AnimatedRotation(
                            turns: expanded ? 0.5 : 0,
                            duration: 250.ms,
                            child: const Icon(Icons.expand_more,
                                color: AppColors.textSecondary, size: 20),
                          ),
                        ],
                      ),
                      AnimatedCrossFade(
                        duration: 250.ms,
                        crossFadeState: expanded
                            ? CrossFadeState.showSecond
                            : CrossFadeState.showFirst,
                        firstChild: const SizedBox.shrink(),
                        secondChild: Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Text(rec.detail,
                              style: const TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 13,
                                  height: 1.5)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ).animate().fadeIn(delay: (60).ms, duration: 300.ms).slideX(begin: 0.05);
          }),
        ],
      ),
    ).animate().fadeIn(duration: 500.ms);
  }
}
