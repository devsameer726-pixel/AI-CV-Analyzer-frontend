/// Data models for the AI CV Analyzer.
///
/// These mirror the JSON shape returned by the `/analyze` REST endpoint and
/// are also used by the mock service layer so the UI renders out-of-the-box.
library;

import 'package:flutter/material.dart';

class MetricScore {
  final String key;
  final String label;
  final double value; // 0..100
  final String description;

  const MetricScore({
    required this.key,
    required this.label,
    required this.value,
    required this.description,
  });

  factory MetricScore.fromJson(Map<String, dynamic> j) => MetricScore(
        key: j['key'] as String,
        label: j['label'] as String,
        value: (j['value'] as num).toDouble(),
        description: j['description'] as String? ?? '',
      );

  Map<String, dynamic> toJson() => {
        'key': key,
        'label': label,
        'value': value,
        'description': description,
      };
}

class SkillTag {
  final String name;
  final bool matched;
  final String? recommendation;

  const SkillTag({
    required this.name,
    required this.matched,
    this.recommendation,
  });

  factory SkillTag.fromJson(Map<String, dynamic> j) => SkillTag(
        name: j['name'] as String,
        matched: j['matched'] as bool,
        recommendation: j['recommendation'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'matched': matched,
        'recommendation': recommendation,
      };
}

class ExperienceSlice {
  final String label;
  final double years;

  const ExperienceSlice({required this.label, required this.years});

  factory ExperienceSlice.fromJson(Map<String, dynamic> j) => ExperienceSlice(
        label: j['label'] as String,
        years: (j['years'] as num).toDouble(),
      );

  Map<String, dynamic> toJson() => {'label': label, 'years': years};
}

class KeywordDensity {
  final String keyword;
  final int count;

  const KeywordDensity({required this.keyword, required this.count});

  factory KeywordDensity.fromJson(Map<String, dynamic> j) => KeywordDensity(
        keyword: j['keyword'] as String,
        count: (j['count'] as num).toInt(),
      );

  Map<String, dynamic> toJson() => {'keyword': keyword, 'count': count};
}

class Recommendation {
  final String id;
  final String title;
  final String detail;
  final RecommendationSeverity severity;

  const Recommendation({
    required this.id,
    required this.title,
    required this.detail,
    required this.severity,
  });

  factory Recommendation.fromJson(Map<String, dynamic> j) => Recommendation(
        id: j['id'] as String,
        title: j['title'] as String,
        detail: j['detail'] as String,
        severity: RecommendationSeverity.values.firstWhere(
          (s) => s.name == j['severity'],
          orElse: () => RecommendationSeverity.info,
        ),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'detail': detail,
        'severity': severity.name,
      };
}

enum RecommendationSeverity { info, warning, critical }

extension RecommendationSeverityX on RecommendationSeverity {
  Color get color => switch (this) {
        RecommendationSeverity.info => const Color(0xFF48CAE4),
        RecommendationSeverity.warning => const Color(0xFFFACC15),
        RecommendationSeverity.critical => const Color(0xFFF87171),
      };

  IconData get icon => switch (this) {
        RecommendationSeverity.info => Icons.lightbulb_outline,
        RecommendationSeverity.warning => Icons.warning_amber_rounded,
        RecommendationSeverity.critical => Icons.error_outline_rounded,
      };
}

class AnalysisResult {
  final double atsScore; // 0..100
  final List<MetricScore> metrics;
  final List<SkillTag> skills;
  final List<ExperienceSlice> experience;
  final List<KeywordDensity> keywords;
  final List<Recommendation> recommendations;
  final String summary;

  const AnalysisResult({
    required this.atsScore,
    required this.metrics,
    required this.skills,
    required this.experience,
    required this.keywords,
    required this.recommendations,
    required this.summary,
  });

  factory AnalysisResult.fromJson(Map<String, dynamic> j) => AnalysisResult(
        atsScore: (j['ats_score'] as num).toDouble(),
        metrics: (j['metrics'] as List)
            .map((e) => MetricScore.fromJson(e as Map<String, dynamic>))
            .toList(),
        skills: (j['skills'] as List)
            .map((e) => SkillTag.fromJson(e as Map<String, dynamic>))
            .toList(),
        experience: (j['experience'] as List)
            .map((e) => ExperienceSlice.fromJson(e as Map<String, dynamic>))
            .toList(),
        keywords: (j['keywords'] as List)
            .map((e) => KeywordDensity.fromJson(e as Map<String, dynamic>))
            .toList(),
        recommendations: (j['recommendations'] as List)
            .map((e) => Recommendation.fromJson(e as Map<String, dynamic>))
            .toList(),
        summary: j['summary'] as String? ?? '',
      );

  Map<String, dynamic> toJson() => {
        'ats_score': atsScore,
        'metrics': metrics.map((e) => e.toJson()).toList(),
        'skills': skills.map((e) => e.toJson()).toList(),
        'experience': experience.map((e) => e.toJson()).toList(),
        'keywords': keywords.map((e) => e.toJson()).toList(),
        'recommendations': recommendations.map((e) => e.toJson()).toList(),
        'summary': summary,
      };
}
